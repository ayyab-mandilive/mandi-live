# Mandi Live – Android starter project

यह Android Studio के लिए Kotlin + Jetpack Compose आधारित शुरुआती प्रोजेक्ट है।

## अभी क्या शामिल है
- Mandi Live का हिंदी Android UI
- फसल चयन: आलू, प्याज, टमाटर, गेहूँ
- पश्चिमी उत्तर प्रदेश की मंडियों के शुरुआती कार्ड
- मंडी तुलना स्क्रीन
- खरीद/बिक्री/भाड़ा आधारित मुनाफा कैलकुलेटर
- स्पष्ट डेटा-स्थिति: कोई नकली भाव लाइव/सत्यापित नहीं दिखाया जाता

## अभी क्या शामिल नहीं है
- APK बाइनरी
- AGMARKNET/e-NAM API कनेक्शन
- लॉगिन, रिपोर्टर सत्यापन, फोटो/पर्ची अपलोड
- सर्वर, डेटाबेस और लाइव पुश अपडेट

## APK बनाने का तरीका
1. Android Studio में इस फोल्डर को Open करें।
2. Gradle sync पूरा होने दें।
3. Build > Build Bundle(s) / APK(s) > Build APK(s) चुनें।
4. Debug APK `app/build/outputs/apk/debug/app-debug.apk` में बनेगा।

## लाइव भाव के लिए अगला तकनीकी चरण
- Backend: FastAPI + PostgreSQL
- आधिकारिक स्रोत: AGMARKNET / e-NAM की उपलब्धता और उपयोग शर्तें जाँचकर integration
- हर रिपोर्ट में: mandi_id, commodity, variety, min/max/modal price, unit, source, observed_at, received_at, evidence
- Verification: आधिकारिक feed या दो स्वतंत्र विश्वसनीय रिपोर्ट; अन्यथा `Reported` / `Unverified`
- पुराना डेटा `Stale` के रूप में दिखे, कभी `Live` नहीं

**महत्वपूर्ण:** स्क्रीन पर दिखाया गया “डेटा उपलब्ध नहीं” वास्तविक लाइव डेटा न होने को दर्शाता है। इसे बाजार भाव न समझें।
