package in.mandilive.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Green = Color(0xFF145A43)
private val LightGreen = Color(0xFFE8F4EE)

data class Market(val name: String, val crop: String, val price: String, val status: String, val time: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MandiLiveApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MandiLiveApp() {
    var crop by remember { mutableStateOf("आलू") }
    var district by remember { mutableStateOf("शामली") }
    var tab by remember { mutableIntStateOf(0) }
    val markets = listOf(
        Market("शामली मंडी", crop, "डेटा उपलब्ध नहीं", "भाव की पुष्टि बाकी", "लाइव स्रोत जुड़ने की प्रतीक्षा"),
        Market("मुजफ्फरनगर मंडी", crop, "डेटा उपलब्ध नहीं", "भाव की पुष्टि बाकी", "लाइव स्रोत जुड़ने की प्रतीक्षा"),
        Market("सहारनपुर मंडी", crop, "डेटा उपलब्ध नहीं", "भाव की पुष्टि बाकी", "लाइव स्रोत जुड़ने की प्रतीक्षा"),
        Market("कैराना मंडी", crop, "डेटा उपलब्ध नहीं", "भाव की पुष्टि बाकी", "लाइव स्रोत जुड़ने की प्रतीक्षा"),
        Market("मेरठ मंडी", crop, "डेटा उपलब्ध नहीं", "भाव की पुष्टि बाकी", "लाइव स्रोत जुड़ने की प्रतीक्षा")
    )
    MaterialTheme(colorScheme = lightColorScheme(primary = Green, secondary = Green)) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Column {
                        Text("MANDI LIVE", fontWeight = FontWeight.ExtraBold, letterSpacing = 1.5.sp)
                        Text("उत्तर प्रदेश • सत्यापित मंडी भाव", fontSize = 12.sp)
                    } },
                    actions = { IconButton(onClick = {}) { Icon(Icons.Default.Notifications, "सूचनाएँ") } }
                )
            },
            bottomBar = {
                NavigationBar {
                    NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Icon(Icons.Default.TrendingUp, null) }, label = { Text("भाव") })
                    NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Icon(Icons.Default.CompareArrows, null) }, label = { Text("तुलना") })
                    NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Icon(Icons.Default.Calculate, null) }, label = { Text("मुनाफा") })
                }
            }
        ) { padding ->
            when (tab) {
                0 -> HomeScreen(padding, crop, { crop = it }, district, { district = it }, markets)
                1 -> CompareScreen(padding)
                else -> ProfitScreen(padding)
            }
        }
    }
}

@Composable
fun HomeScreen(
    padding: PaddingValues, crop: String, onCrop: (String) -> Unit,
    district: String, onDistrict: (String) -> Unit, markets: List<Market>
) {
    LazyColumn(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = Green), shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp)) {
                    Text("आज का मंडी बाजार", color = Color.White.copy(alpha = .8f))
                    Spacer(Modifier.height(6.dp))
                    Text("भाव तभी दिखेगा जब स्रोत सत्यापित होगा", color = Color.White, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp))
                    Text("कोई अनुमानित या पुराना भाव लाइव बताकर नहीं दिखाया जाएगा।", color = Color.White.copy(alpha = .85f), fontSize = 13.sp)
                }
            }
        }
        item { Text("फसल चुनें", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("आलू", "प्याज", "टमाटर", "गेहूँ").forEach { item ->
                    FilterChip(selected = crop == item, onClick = { onCrop(item) }, label = { Text(item) })
                }
            }
        }
        item { Text("मंडी और जिला", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        item {
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("शामली", "मुजफ्फरनगर", "सहारनपुर").forEach {
                    FilterChip(selected = district == it, onClick = { onDistrict(it) }, label = { Text(it) })
                }
            }
        }
        item { Text("मंडी भाव", fontWeight = FontWeight.Bold, fontSize = 17.sp) }
        items(markets.filter { it.name.contains(district) || district == "शामली" }) { market ->
            MarketCard(market)
        }
        item {
            Text("डेटा स्थिति: यह शुरुआती UI डेमो है। लाइव सरकारी/मंडी API अभी कनेक्ट नहीं है।",
                color = Color.Gray, fontSize = 12.sp, modifier = Modifier.padding(vertical = 10.dp))
        }
    }
}

@Composable
fun MarketCard(m: Market) {
    Card(modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(16.dp)) {
        Column(Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                Text(m.name, fontWeight = FontWeight.Bold)
                AssistChip(onClick = {}, label = { Text("असत्यापित") }, leadingIcon = { Icon(Icons.Default.Info, null) })
            }
            Text("${m.crop} • प्रति क्विंटल", color = Color.Gray, fontSize = 12.sp)
            Spacer(Modifier.height(8.dp))
            Text(m.price, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Green)
            Text(m.time, fontSize = 12.sp, color = Color.Gray)
        }
    }
}

@Composable
fun CompareScreen(padding: PaddingValues) {
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("मंडी तुलना", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        Text("एक ही फसल और समान गुणवत्ता के सत्यापित भाव मिलने पर मंडियों की तुलना दिखाई जाएगी।")
        listOf("शामली", "मुजफ्फरनगर", "सहारनपुर", "दिल्ली – आजादपुर").forEach {
            ListItem(headlineContent = { Text(it) }, supportingContent = { Text("लाइव डेटा स्रोत जुड़ना बाकी") }, leadingContent = { Icon(Icons.Default.LocationOn, null) })
        }
    }
}

@Composable
fun ProfitScreen(padding: PaddingValues) {
    var buy by remember { mutableStateOf("1000") }
    var sell by remember { mutableStateOf("1400") }
    var quantity by remember { mutableStateOf("20") }
    var freight by remember { mutableStateOf("2000") }
    val b = buy.toDoubleOrNull() ?: 0.0
    val s = sell.toDoubleOrNull() ?: 0.0
    val q = quantity.toDoubleOrNull() ?: 0.0
    val f = freight.toDoubleOrNull() ?: 0.0
    val profit = (s - b) * q - f
    Column(Modifier.fillMaxSize().padding(padding).padding(20.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("मुनाफा कैलकुलेटर", fontSize = 23.sp, fontWeight = FontWeight.Bold)
        PriceField("खरीद भाव (₹/क्विंटल)", buy) { buy = it }
        PriceField("बिक्री भाव (₹/क्विंटल)", sell) { sell = it }
        PriceField("मात्रा (क्विंटल)", quantity) { quantity = it }
        PriceField("कुल भाड़ा/खर्च (₹)", freight) { freight = it }
        Card(colors = CardDefaults.cardColors(containerColor = LightGreen)) {
            Column(Modifier.padding(16.dp)) {
                Text("अनुमानित शुद्ध मुनाफा", color = Green)
                Text("₹${"%.2f".format(profit)}", fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Green)
                Text("यह गणना आपके डाले गए आंकड़ों पर आधारित है।", fontSize = 11.sp, color = Color.DarkGray)
            }
        }
    }
}

@Composable
fun PriceField(label: String, value: String, onChange: (String) -> Unit) {
    OutlinedTextField(value, onChange, label = { Text(label) }, modifier = Modifier.fillMaxWidth(), singleLine = true)
}
